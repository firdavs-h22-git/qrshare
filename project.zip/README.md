# FountainQR

Wi-Fi, Bluetooth va internetsiz fayl uzatish: yuboruvchi telefon ekranida tez almashinadigan QR kodlar,
qabul qiluvchi telefon kamerasi ularni o'qib faylni qayta tiklaydi. Fountain (LT) kod ishlatilgani uchun
qaysi kadrlar o'tib ketgani muhim emas.

## GitHub'da APK olish
1. GitHub'da yangi repo oching va shu papkadagi hamma fayllarni yuklang (`.github` papkasi bilan).
2. `main` branchga push qiling. **Actions** bo'limida "Build APK" ishga tushadi (~3-5 daqiqa).
3. Tugagach, run sahifasining pastida **Artifacts → FountainQR-debug-apk** ni yuklab oling, ichida `app-debug.apk`.
4. Ikkala telefonga o'rnating.

Build xato bersa, Actions logining oxirgi qismini yuboring.

## Ishlatish
- Yuboruvchi: Yuborish → fayl tanlash → "Yuborishni boshlash"
- Qabul qiluvchi: Qabul qilish → kamerani QR ga qarating → tugagach "Faylni saqlash"
- Telefonlarni qimirlatmang, masofa ~15–25 sm. QR o'qilmasa kadr hajmini yoki tezlikni kamaytiring.

## Kadr formati
`FQ1.<sessiya>.<hajm>.<blok>.<crc32>.<seed>.<nom b64>.<ma'lumot b64>`
