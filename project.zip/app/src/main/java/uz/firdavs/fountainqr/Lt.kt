package uz.firdavs.fountainqr

import java.util.LinkedList
import kotlin.math.ln
import kotlin.math.sqrt

/** Deterministik PRNG (splitmix64) — yuboruvchi va qabul qiluvchida bir xil natija beradi. */
class Rng(seed: Long) {
    private var s = seed

    fun nextLong(): Long {
        s += GOLDEN
        var z = s
        z = (z xor (z ushr 30)) * M1
        z = (z xor (z ushr 27)) * M2
        return z xor (z ushr 31)
    }

    fun nextDouble(): Double = (nextLong() ushr 11).toDouble() / 9007199254740992.0

    fun nextInt(bound: Int): Int = ((nextLong() ushr 1) % bound).toInt()

    companion object {
        private val GOLDEN = 0x9E3779B97F4A7C15UL.toLong()
        private val M1 = 0xBF58476D1CE4E5B9UL.toLong()
        private val M2 = 0x94D049BB133111EBUL.toLong()
    }
}

/**
 * LT (fountain) kod parametrlari. seed < k bo'lsa — oddiy (systematic) blok,
 * aks holda robust soliton taqsimoti bo'yicha tasodifiy bloklar yig'indisi (XOR).
 */
class LtParams(val k: Int) {
    private val cdf: DoubleArray = buildCdf(k)

    private fun buildCdf(k: Int): DoubleArray {
        val p = DoubleArray(k + 1)
        if (k == 1) {
            p[1] = 1.0
        } else {
            val c = 0.1
            val delta = 0.5
            val r = c * ln(k / delta) * sqrt(k.toDouble())
            val pivot = (k / r).toInt().coerceIn(1, k)
            p[1] = 1.0 / k
            for (d in 2..k) p[d] = 1.0 / (d * (d - 1.0))
            for (d in 1 until pivot) p[d] += r / (d.toDouble() * k)
            val extra = r * ln(r / delta) / k
            if (extra > 0) p[pivot] += extra
        }
        val sum = p.sum()
        var acc = 0.0
        for (d in 1..k) {
            acc += p[d] / sum
            p[d] = acc
        }
        p[k] = 1.0
        return p
    }

    fun indicesFor(seed: Int): IntArray {
        if (seed < k) return intArrayOf(seed)
        val rng = Rng(seed.toLong() * 1_000_003L + k)
        val u = rng.nextDouble()
        var lo = 1
        var hi = k
        while (lo < hi) {
            val mid = (lo + hi) ushr 1
            if (cdf[mid] >= u) hi = mid else lo = mid + 1
        }
        val set = LinkedHashSet<Int>()
        while (set.size < lo) set.add(rng.nextInt(k))
        return set.toIntArray()
    }
}

class LtEncoder(private val data: ByteArray, val blockSize: Int) {
    val k: Int = (data.size + blockSize - 1) / blockSize
    private val params = LtParams(k)

    fun block(seed: Int): ByteArray {
        val out = ByteArray(blockSize)
        for (i in params.indicesFor(seed)) {
            val off = i * blockSize
            val n = minOf(blockSize, data.size - off)
            for (j in 0 until n) {
                out[j] = (out[j].toInt() xor data[off + j].toInt()).toByte()
            }
        }
        return out
    }
}

/** Peeling dekoder: kadrlar qaysi tartibda va qaysilari tushib qolishidan qat'i nazar ishlaydi. */
class LtDecoder(val k: Int, val bs: Int) {
    private class Eq(val idx: HashSet<Int>, val data: ByteArray) {
        var done = false
    }

    private val params = LtParams(k)
    private val decoded = arrayOfNulls<ByteArray>(k)
    private val seen = HashSet<Int>()
    private val watch = Array(k) { ArrayList<Eq>(2) }

    var decodedCount = 0
        private set

    val isComplete: Boolean get() = decodedCount == k

    /** Yangi (takrorlanmagan) kadr bo'lsa true qaytaradi. */
    fun add(seed: Int, payload: ByteArray): Boolean {
        if (seed < 0 || payload.size != bs) return false
        if (!seen.add(seed)) return false
        val data = payload.copyOf()
        val set = HashSet<Int>()
        for (i in params.indicesFor(seed)) {
            val known = decoded[i]
            if (known != null) xorInto(data, known) else set.add(i)
        }
        when {
            set.isEmpty() -> {}
            set.size == 1 -> process(set.first(), data)
            else -> {
                val eq = Eq(set, data)
                for (i in set) watch[i].add(eq)
            }
        }
        return true
    }

    private fun process(first: Int, firstData: ByteArray) {
        val queue = LinkedList<Pair<Int, ByteArray>>()
        queue.add(Pair(first, firstData))
        while (true) {
            val item = queue.poll() ?: break
            val i = item.first
            val d = item.second
            if (decoded[i] != null) continue
            decoded[i] = d
            decodedCount++
            val list = watch[i]
            for (eq in list) {
                if (eq.done) continue
                if (eq.idx.remove(i)) xorInto(eq.data, d)
                if (eq.idx.size == 1) {
                    eq.done = true
                    queue.add(Pair(eq.idx.first(), eq.data))
                } else if (eq.idx.isEmpty()) {
                    eq.done = true
                }
            }
            list.clear()
        }
    }

    fun result(size: Int): ByteArray {
        val out = ByteArray(size)
        for (i in 0 until k) {
            val b = decoded[i]!!
            val off = i * bs
            val n = minOf(bs, size - off)
            System.arraycopy(b, 0, out, off, n)
        }
        return out
    }

    private fun xorInto(dst: ByteArray, src: ByteArray) {
        for (j in dst.indices) dst[j] = (dst[j].toInt() xor src[j].toInt()).toByte()
    }
}
