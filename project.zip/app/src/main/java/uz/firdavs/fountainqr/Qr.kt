package uz.firdavs.fountainqr

import android.graphics.Bitmap
import android.graphics.Color
import com.google.zxing.qrcode.decoder.ErrorCorrectionLevel
import com.google.zxing.qrcode.encoder.Encoder

object Qr {
    /** 1 modul = 1 piksel; Compose'da FilterQuality.None bilan keskin kattalashtiriladi. */
    fun bitmap(text: String): Bitmap {
        val matrix = Encoder.encode(text, ErrorCorrectionLevel.L).matrix
        val n = matrix.width
        val quiet = 4
        val size = n + quiet * 2
        val px = IntArray(size * size) { Color.WHITE }
        for (y in 0 until n) {
            for (x in 0 until n) {
                if (matrix.get(x, y).toInt() == 1) px[(y + quiet) * size + x + quiet] = Color.BLACK
            }
        }
        val bmp = Bitmap.createBitmap(size, size, Bitmap.Config.ARGB_8888)
        bmp.setPixels(px, 0, size, 0, 0, size, size)
        return bmp
    }
}
