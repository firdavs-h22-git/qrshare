package uz.firdavs.fountainqr

import android.Manifest
import android.content.pm.PackageManager
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.util.Locale

@Composable
fun ReceiveScreen(onBack: () -> Unit) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    val rx = remember { Receiver() }
    var saveMsg by remember { mutableStateOf("") }

    KeepAwake(bright = false)

    var granted by remember {
        mutableStateOf(
            ContextCompat.checkSelfPermission(context, Manifest.permission.CAMERA) ==
                PackageManager.PERMISSION_GRANTED
        )
    }
    val permLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) {
        granted = it
    }
    LaunchedEffect(Unit) {
        if (!granted) permLauncher.launch(Manifest.permission.CAMERA)
    }

    val saver = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("*/*")) { uri ->
        val bytes = rx.result
        if (uri != null && bytes != null) {
            scope.launch {
                val ok = withContext(Dispatchers.IO) {
                    runCatching {
                        context.contentResolver.openOutputStream(uri)?.use { it.write(bytes) }
                            ?: error("stream")
                    }.isSuccess
                }
                saveMsg = if (ok) "Saqlandi ✔" else "Saqlashda xatolik"
            }
        }
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        ScreenHeader("Qabul qilish", onBack)

        val result = rx.result
        val h = rx.header

        if (result != null && h != null) {
            Card(
                modifier = Modifier.fillMaxWidth(),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)
            ) {
                Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text("✔ Qabul qilindi", fontSize = 20.sp, color = Color(0xFF4CD964))
                    Text(h.name, fontSize = 16.sp)
                    val secs = rx.elapsedMs / 1000.0
                    val speed = if (rx.elapsedMs > 0) result.size / 1024.0 / secs else 0.0
                    Text(
                        "${fmtSize(result.size.toLong())} • ${String.format(Locale.US, "%.1f", secs)} s • " +
                            String.format(Locale.US, "%.1f KB/s", speed),
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                    Text("Tekshiruv (CRC32): to'g'ri", color = MaterialTheme.colorScheme.onSurfaceVariant)
                    if (saveMsg.isNotEmpty()) Text(saveMsg)
                }
            }
            Button(onClick = { saver.launch(h.name) }, modifier = Modifier.fillMaxWidth()) {
                Text("Faylni saqlash")
            }
            OutlinedButton(
                onClick = {
                    saveMsg = ""
                    rx.reset()
                },
                modifier = Modifier.fillMaxWidth()
            ) {
                Text("Yangi qabul")
            }
        } else if (!granted) {
            Text("Kamera ruxsati kerak.", color = MaterialTheme.colorScheme.onSurfaceVariant)
            Button(onClick = { permLauncher.launch(Manifest.permission.CAMERA) }) {
                Text("Ruxsat berish")
            }
        } else {
            CameraScanner(
                modifier = Modifier
                    .fillMaxWidth()
                    .aspectRatio(3f / 4f)
                    .clip(RoundedCornerShape(16.dp)),
                onFrame = { rx.onAnalyzed(it) }
            )

            val total = rx.total
            val progress = if (total > 0) rx.decoded.toFloat() / total else 0f
            LinearProgressIndicator(progress = { progress }, modifier = Modifier.fillMaxWidth())

            Card(
                modifier = Modifier.fillMaxWidth(),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)
            ) {
                Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                    val kbs = if (rx.elapsedMs > 0 && h != null) {
                        rx.decoded.toLong() * h.bs * 1000.0 / rx.elapsedMs / 1024.0
                    } else 0.0
                    Row(Modifier.fillMaxWidth()) {
                        Stat("Kamera FPS", "${rx.camFps}", Modifier.weight(1f))
                        Stat("Bloklar", "${rx.decoded}/${rx.total}", Modifier.weight(1f))
                    }
                    Row(Modifier.fillMaxWidth()) {
                        Stat("Qabul kadrlar", "${rx.unique}", Modifier.weight(1f))
                        Stat("Tezlik", String.format(Locale.US, "%.1f KB/s", kbs), Modifier.weight(1f))
                    }
                    Row(Modifier.fillMaxWidth()) {
                        Stat("Fayl", h?.name ?: "—", Modifier.weight(1f))
                        Stat("Vaqt", String.format(Locale.US, "%.1f s", rx.elapsedMs / 1000.0), Modifier.weight(1f))
                    }
                }
            }
            Text(
                if (rx.note.isNotEmpty()) rx.note
                else if (h == null) "Kamerani yuboruvchi telefon QR iga qarating"
                else "Qabul qilinmoqda... telefonni qimirlatmang",
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
        }
    }
}
