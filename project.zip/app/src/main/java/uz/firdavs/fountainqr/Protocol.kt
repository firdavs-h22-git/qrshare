package uz.firdavs.fountainqr

import android.util.Base64

data class Header(val sid: String, val size: Int, val bs: Int, val crc: Long, val name: String)

class Frame(val header: Header, val seed: Int, val data: ByteArray)

object Protocol {
    const val MAX_SIZE = 16 * 1024 * 1024
    private const val TAG = "FQ1"
    private const val B64 = Base64.URL_SAFE or Base64.NO_PADDING or Base64.NO_WRAP

    fun encode(h: Header, seed: Int, data: ByteArray): String {
        val name = Base64.encodeToString(h.name.take(40).toByteArray(Charsets.UTF_8), B64)
        val payload = Base64.encodeToString(data, B64)
        return "$TAG.${h.sid}.${h.size}.${h.bs}.${java.lang.Long.toHexString(h.crc)}.$seed.$name.$payload"
    }

    fun parse(text: String): Frame? {
        if (!text.startsWith("$TAG.")) return null
        val p = text.split('.')
        if (p.size != 8) return null
        return try {
            val size = p[2].toInt()
            val bs = p[3].toInt()
            if (size <= 0 || size > MAX_SIZE || bs < 100 || bs > 3000) return null
            val seed = p[5].toInt()
            if (seed < 0) return null
            val data = Base64.decode(p[7], B64)
            if (data.size != bs) return null
            val name = String(Base64.decode(p[6], B64), Charsets.UTF_8).ifBlank { "file" }
            Frame(Header(p[1], size, bs, p[4].toLong(16), name), seed, data)
        } catch (e: Exception) {
            null
        }
    }
}
