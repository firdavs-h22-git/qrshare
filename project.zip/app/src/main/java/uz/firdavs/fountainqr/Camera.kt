package uz.firdavs.fountainqr

import android.util.Size
import androidx.camera.core.CameraSelector
import androidx.camera.core.ImageAnalysis
import androidx.camera.core.ImageProxy
import androidx.camera.core.Preview
import androidx.camera.core.resolutionselector.ResolutionSelector
import androidx.camera.core.resolutionselector.ResolutionStrategy
import androidx.camera.lifecycle.ProcessCameraProvider
import androidx.camera.view.PreviewView
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalLifecycleOwner
import androidx.compose.ui.viewinterop.AndroidView
import androidx.core.content.ContextCompat
import com.google.mlkit.vision.barcode.BarcodeScanner
import com.google.mlkit.vision.barcode.BarcodeScannerOptions
import com.google.mlkit.vision.barcode.BarcodeScanning
import com.google.mlkit.vision.barcode.common.Barcode
import com.google.mlkit.vision.common.InputImage
import java.util.concurrent.Executors
import java.util.concurrent.atomic.AtomicBoolean

@Suppress("UnsafeOptInUsageError")
private class QrAnalyzer(
    private val scanner: BarcodeScanner,
    private val onResult: (List<String>) -> Unit
) : ImageAnalysis.Analyzer {
    override fun analyze(image: ImageProxy) {
        try {
            val media = image.image
            if (media == null) {
                image.close()
                return
            }
            val input = InputImage.fromMediaImage(media, image.imageInfo.rotationDegrees)
            scanner.process(input)
                .addOnSuccessListener { codes -> onResult(codes.mapNotNull { it.rawValue }) }
                .addOnFailureListener { onResult(emptyList()) }
                .addOnCompleteListener { image.close() }
        } catch (e: Exception) {
            image.close()
        }
    }
}

/** Orqa kamera + ML Kit QR skaner. Har bir tahlil qilingan kadr uchun onFrame chaqiriladi (main thread). */
@Composable
fun CameraScanner(modifier: Modifier = Modifier, onFrame: (List<String>) -> Unit) {
    val owner = LocalLifecycleOwner.current
    val latest by rememberUpdatedState(onFrame)
    val executor = remember { Executors.newSingleThreadExecutor() }
    val scanner = remember {
        BarcodeScanning.getClient(
            BarcodeScannerOptions.Builder().setBarcodeFormats(Barcode.FORMAT_QR_CODE).build()
        )
    }
    val holder = remember { arrayOfNulls<ProcessCameraProvider>(1) }
    val alive = remember { AtomicBoolean(true) }

    DisposableEffect(Unit) {
        onDispose {
            alive.set(false)
            holder[0]?.unbindAll()
            executor.shutdown()
            scanner.close()
        }
    }

    AndroidView(
        modifier = modifier,
        factory = { ctx ->
            val previewView = PreviewView(ctx)
            val future = ProcessCameraProvider.getInstance(ctx)
            future.addListener({
                if (!alive.get()) return@addListener
                val provider = future.get()
                holder[0] = provider
                val preview = Preview.Builder().build().also {
                    it.setSurfaceProvider(previewView.surfaceProvider)
                }
                val selector = ResolutionSelector.Builder()
                    .setResolutionStrategy(
                        ResolutionStrategy(
                            Size(1920, 1080),
                            ResolutionStrategy.FALLBACK_RULE_CLOSEST_HIGHER_THEN_LOWER
                        )
                    )
                    .build()
                val analysis = ImageAnalysis.Builder()
                    .setResolutionSelector(selector)
                    .setBackpressureStrategy(ImageAnalysis.STRATEGY_KEEP_ONLY_LATEST)
                    .build()
                analysis.setAnalyzer(executor, QrAnalyzer(scanner) { latest(it) })
                provider.unbindAll()
                provider.bindToLifecycle(owner, CameraSelector.DEFAULT_BACK_CAMERA, preview, analysis)
            }, ContextCompat.getMainExecutor(ctx))
            previewView
        }
    )
}
