package uz.firdavs.fountainqr

import android.content.Context
import android.graphics.Bitmap
import android.net.Uri
import android.provider.OpenableColumns
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Slider
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.FilterQuality
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.util.Locale
import java.util.zip.CRC32
import kotlin.math.roundToInt
import kotlin.random.Random

private class FileProblem(text: String) : Exception(text)

private fun readFile(context: Context, uri: Uri): Pair<String, ByteArray> {
    var name = "file"
    var declared = -1L
    context.contentResolver.query(uri, null, null, null, null)?.use { c ->
        if (c.moveToFirst()) {
            val ni = c.getColumnIndex(OpenableColumns.DISPLAY_NAME)
            val si = c.getColumnIndex(OpenableColumns.SIZE)
            if (ni >= 0) c.getString(ni)?.let { name = it }
            if (si >= 0 && !c.isNull(si)) declared = c.getLong(si)
        }
    }
    val tooBig = "Fayl juda katta (maksimum ${Protocol.MAX_SIZE / 1048576} MB)"
    if (declared > Protocol.MAX_SIZE) throw FileProblem(tooBig)
    val bytes = context.contentResolver.openInputStream(uri)?.use { it.readBytes() }
        ?: throw FileProblem("Faylni ochib bo'lmadi")
    if (bytes.size > Protocol.MAX_SIZE) throw FileProblem(tooBig)
    if (bytes.isEmpty()) throw FileProblem("Fayl bo'sh")
    return Pair(name, bytes)
}

@Composable
fun SendScreen(onBack: () -> Unit) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()

    var fileName by remember { mutableStateOf<String?>(null) }
    var data by remember { mutableStateOf<ByteArray?>(null) }
    var loading by remember { mutableStateOf(false) }
    var error by remember { mutableStateOf<String?>(null) }
    var blockSize by remember { mutableIntStateOf(1000) }
    var fps by remember { mutableFloatStateOf(8f) }
    var running by remember { mutableStateOf(false) }
    var frame by remember { mutableStateOf<Bitmap?>(null) }
    var seed by remember { mutableIntStateOf(0) }
    val fpsNow by rememberUpdatedState(fps)

    KeepAwake(bright = running)

    val picker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) {
            running = false
            loading = true
            error = null
            scope.launch {
                val res = withContext(Dispatchers.IO) { runCatching { readFile(context, uri) } }
                loading = false
                res.onSuccess {
                    fileName = it.first
                    data = it.second
                }.onFailure {
                    data = null
                    fileName = null
                    error = if (it is FileProblem) it.message else "Faylni o'qib bo'lmadi (xotira yetmadi?)"
                }
            }
        }
    }

    LaunchedEffect(running, data, blockSize) {
        val bytes = data
        if (!running || bytes == null) return@LaunchedEffect
        val name = fileName ?: "file"
        val crc = withContext(Dispatchers.Default) { CRC32().apply { update(bytes) }.value }
        val sid = java.lang.Long.toHexString(Random.nextLong() and 0xFFFFFFFFL)
        val header = Header(sid, bytes.size, blockSize, crc, name)
        val enc = LtEncoder(bytes, blockSize)
        var s = 0
        while (isActive) {
            val t0 = System.nanoTime()
            val bmp = withContext(Dispatchers.Default) {
                Qr.bitmap(Protocol.encode(header, s, enc.block(s)))
            }
            frame = bmp
            seed = s
            s++
            val interval = (1000f / fpsNow).toLong()
            val spent = (System.nanoTime() - t0) / 1_000_000
            delay(maxOf(1L, interval - spent))
        }
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        ScreenHeader("Yuborish", onBack)

        val bytes = data
        if (!running) {
            Card(
                modifier = Modifier.fillMaxWidth(),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)
            ) {
                Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    if (bytes != null) {
                        Text(fileName ?: "file", fontSize = 16.sp)
                        Text(fmtSize(bytes.size.toLong()), color = MaterialTheme.colorScheme.onSurfaceVariant)
                    } else {
                        Text("Fayl tanlanmagan", color = MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                    if (loading) Text("O'qilmoqda...")
                    error?.let { Text(it, color = Color(0xFFFF6B6B)) }
                    OutlinedButton(onClick = { picker.launch(arrayOf("*/*")) }) {
                        Text(if (bytes == null) "Fayl tanlash" else "Boshqa fayl tanlash")
                    }
                }
            }

            Text("Kadr hajmi (bayt)", color = MaterialTheme.colorScheme.onSurfaceVariant)
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.fillMaxWidth()) {
                for (size in listOf(500, 1000, 1500, 2000)) {
                    val selected = size == blockSize
                    val mod = Modifier.weight(1f)
                    if (selected) {
                        Button(onClick = { blockSize = size }, modifier = mod, contentPadding = PaddingValues(0.dp)) {
                            Text("$size")
                        }
                    } else {
                        OutlinedButton(onClick = { blockSize = size }, modifier = mod, contentPadding = PaddingValues(0.dp)) {
                            Text("$size")
                        }
                    }
                }
            }

            Text("Tezlik: ${fps.roundToInt()} kadr/s", color = MaterialTheme.colorScheme.onSurfaceVariant)
            Slider(value = fps, onValueChange = { fps = it }, valueRange = 1f..30f, steps = 28)

            val kbps = blockSize * fps.roundToInt() / 1024f
            Text(
                String.format(Locale.US, "Nazariy tezlik ≈ %.1f KB/s", kbps),
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
            if (bytes != null) {
                val secs = bytes.size / (blockSize * fps.roundToInt().toFloat()) * 1.2f
                Text(
                    String.format(Locale.US, "Taxminiy vaqt ≈ %.0f s", secs),
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
            Text(
                "Qabul qiluvchi telefon QR ni o'qiy olmasa, kadr hajmini yoki tezlikni kamaytiring.",
                fontSize = 12.sp,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
        }

        Box(
            modifier = Modifier
                .fillMaxWidth()
                .aspectRatio(1f)
                .background(Color.White),
            contentAlignment = Alignment.Center
        ) {
            val f = frame
            if (running && f != null) {
                Image(
                    bitmap = f.asImageBitmap(),
                    contentDescription = null,
                    modifier = Modifier.fillMaxSize(),
                    filterQuality = FilterQuality.None
                )
            } else {
                Text("QR shu yerda ko'rinadi", color = Color.Gray)
            }
        }

        if (running && bytes != null) {
            val k = (bytes.size + blockSize - 1) / blockSize
            Text(
                "Kadr #${seed + 1} • ${k} ta blok • ${fps.roundToInt()} kadr/s",
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
        }

        Button(
            onClick = {
                if (running) {
                    running = false
                    frame = null
                } else {
                    running = true
                }
            },
            enabled = bytes != null && !loading,
            modifier = Modifier.fillMaxWidth()
        ) {
            Text(if (running) "To'xtatish" else "Yuborishni boshlash")
        }
    }
}
