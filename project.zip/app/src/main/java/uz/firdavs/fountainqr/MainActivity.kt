package uz.firdavs.fountainqr

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.Button
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

enum class Screen { Home, Send, Receive }

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            MaterialTheme(
                colorScheme = darkColorScheme(
                    primary = Color(0xFFFFB020),
                    onPrimary = Color.Black,
                    secondary = Color(0xFFFFB020),
                    background = Color(0xFF0F1115),
                    surface = Color(0xFF181B22),
                    surfaceVariant = Color(0xFF232733),
                    onBackground = Color(0xFFE8E8E8),
                    onSurface = Color(0xFFE8E8E8),
                    onSurfaceVariant = Color(0xFFB8BCC8)
                )
            ) {
                App()
            }
        }
    }
}

@Composable
fun App() {
    var screen by remember { mutableStateOf(Screen.Home) }
    BackHandler(enabled = screen != Screen.Home) { screen = Screen.Home }

    Surface(modifier = Modifier.fillMaxSize(), color = MaterialTheme.colorScheme.background) {
        when (screen) {
            Screen.Home -> Home(
                onSend = { screen = Screen.Send },
                onReceive = { screen = Screen.Receive }
            )
            Screen.Send -> SendScreen(onBack = { screen = Screen.Home })
            Screen.Receive -> ReceiveScreen(onBack = { screen = Screen.Home })
        }
    }
}

@Composable
fun Home(onSend: () -> Unit, onReceive: () -> Unit) {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(24.dp),
        verticalArrangement = Arrangement.Center,
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Text("FountainQR", fontSize = 32.sp, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary)
        Spacer(Modifier.height(8.dp))
        Text(
            "Wi-Fi, Bluetooth va internetsiz fayl uzatish.\nFayl tez almashinadigan QR kodlar oqimi orqali o'tadi.",
            textAlign = TextAlign.Center,
            color = MaterialTheme.colorScheme.onSurfaceVariant
        )
        Spacer(Modifier.height(40.dp))
        Button(onClick = onSend, modifier = Modifier.fillMaxWidth().height(56.dp)) {
            Text("Yuborish", fontSize = 18.sp)
        }
        Spacer(Modifier.height(12.dp))
        OutlinedButton(onClick = onReceive, modifier = Modifier.fillMaxWidth().height(56.dp)) {
            Text("Qabul qilish", fontSize = 18.sp)
        }
        Spacer(Modifier.height(24.dp))
        Text(
            "Maksimal fayl hajmi: ${Protocol.MAX_SIZE / 1048576} MB",
            fontSize = 12.sp,
            color = MaterialTheme.colorScheme.onSurfaceVariant
        )
    }
}
