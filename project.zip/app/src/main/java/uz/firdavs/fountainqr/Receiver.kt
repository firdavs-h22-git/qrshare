package uz.firdavs.fountainqr

import android.os.SystemClock
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import java.util.zip.CRC32

/** Kameradan kelgan QR matnlarini yig'adi va faylni tiklaydi. */
class Receiver {
    private var decoder: LtDecoder? = null
    private var startedAt = 0L
    private var winStart = 0L
    private var winCount = 0

    var header by mutableStateOf<Header?>(null)
        private set
    var decoded by mutableIntStateOf(0)
        private set
    var total by mutableIntStateOf(0)
        private set
    var unique by mutableIntStateOf(0)
        private set
    var camFps by mutableIntStateOf(0)
        private set
    var elapsedMs by mutableLongStateOf(0L)
        private set
    var result by mutableStateOf<ByteArray?>(null)
        private set
    var note by mutableStateOf("")
        private set

    fun onAnalyzed(texts: List<String>) {
        val now = SystemClock.elapsedRealtime()
        if (winStart == 0L) winStart = now
        winCount++
        if (now - winStart >= 1000) {
            camFps = winCount
            winCount = 0
            winStart = now
        }
        if (result != null) return
        for (t in texts) {
            val f = Protocol.parse(t) ?: continue
            accept(f, now)
            if (result != null) return
        }
        if (decoder != null) elapsedMs = now - startedAt
    }

    private fun accept(f: Frame, now: Long) {
        val cur = header
        var dec = decoder
        if (cur == null || dec == null || cur.sid != f.header.sid) {
            val h = f.header
            val k = (h.size + h.bs - 1) / h.bs
            dec = LtDecoder(k, h.bs)
            decoder = dec
            header = h
            total = k
            decoded = 0
            unique = 0
            startedAt = now
            elapsedMs = 0L
            note = ""
        }
        val h = header ?: return
        if (dec.add(f.seed, f.data)) unique++
        decoded = dec.decodedCount
        if (dec.isComplete) finish(dec, h, now)
    }

    private fun finish(dec: LtDecoder, h: Header, now: Long) {
        val bytes = dec.result(h.size)
        val crc = CRC32().apply { update(bytes) }.value
        if (crc == h.crc) {
            elapsedMs = now - startedAt
            result = bytes
            note = ""
        } else {
            note = "Nazorat summasi (CRC) mos kelmadi — qayta qabul qilinmoqda"
            decoder = null
            header = null
            decoded = 0
            total = 0
        }
    }

    fun reset() {
        decoder = null
        header = null
        result = null
        decoded = 0
        total = 0
        unique = 0
        elapsedMs = 0L
        note = ""
    }
}
